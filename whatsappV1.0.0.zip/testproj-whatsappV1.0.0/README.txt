this is from ser

9 set 2020

new data r=from the remote git


demo .gitgnore





ver

this is extra info
latest data

newdata
